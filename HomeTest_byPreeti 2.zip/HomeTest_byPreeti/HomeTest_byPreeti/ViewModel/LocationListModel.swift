//
//  LocationListModel.swift
//  HomeTest_byPreeti
//
//  Created by Preeti Dhankar on 28/01/24.
//

import Foundation

import Combine

class LocationListModel: ObservableObject {
    
    var customError: NetworkError?
    var isLoading: Bool = false
    var LocationList: [locations] = []
    private let networkManager: NetworkAbleProtocol
    private var cancellables = Set<AnyCancellable>()
    init(networkManager: NetworkAbleProtocol) {
        self.networkManager = networkManager
    }
    
    func fetchLocations(request: URLRequest? = nil, completion: @escaping ([locations]) -> ()) {
        
        guard let urlRequest = UrlGen.shared.from(ApiManager.api(.locationsList)) else {
            isLoading = false
            customError = .invalidUrlError
            return
        }
        self.networkManager.getDataFromApi(urlRequest: (request != nil) ? request! : urlRequest, type: LocationData.self)
            .receive(on: RunLoop.main)
            .sink { completion in
                switch completion {
                case .finished:
                    print("Finished Case")
                    self.isLoading = false
                case .failure(let error):
                    self.customError = NetworkError.getNetwork(error: error)
                    print(error.localizedDescription)
                    self.isLoading = false
                }
            } receiveValue: { value in
                completion(value.locations)
            }.store(in: &cancellables)
    }
    
    

}
