//
//  FetchLocationsUnitTest.swift
//  HomeTest_byPreetiTests
//
//  Created by Preeti Dhankar on 29/01/24.
//

import XCTest
@testable import HomeTest_byPreeti

final class FetchLocationsUnitTest: XCTestCase {
    let locationListModel = LocationListModel(networkManager: NetworkManager())
    
    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }
    
    func testFetchLocations_success() {
        let expectation = self.expectation(description: "Fetch locations data")
        locationListModel.fetchLocations { locations in
            if locations.count > 0 {
                XCTAssertEqual("Milsons Point".lowercased(), locations.first?.name.lowercased())
            } else {
                XCTFail("No Data Found")
            }
            expectation.fulfill()
        }
        wait(for: [expectation], timeout: 5.0)
    }
    
    func testFetchLocations_failure() {
        let expectation = self.expectation(description: "Fetch locations data")
        guard let request = UrlGen.shared.from(ApiManager.api(.errorLocationsList)) else {
            return
        }
        
        locationListModel.fetchLocations(request: request) { locations in
            if locations.count > 0 {
                XCTAssertEqual("Milsons Point".lowercased(), locations.first?.name.lowercased())
            } else {
                XCTFail("Invalid URL")
            }
            expectation.fulfill()
        }
        wait(for: [expectation], timeout: 5.0)
        
        
    }

}
