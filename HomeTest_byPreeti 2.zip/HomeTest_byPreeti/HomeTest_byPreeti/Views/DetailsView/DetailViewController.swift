//
//  DetailViewController.swift
//  HomeTest_byPreeti
//
//  Created by Preeti Dhankar on 28/01/24.
//

import UIKit
import CoreData


class DetailViewController: UIViewController,UITextViewDelegate {
    var reloadAction: (() -> Void)?
   
    @IBOutlet weak var haertBtn: UIImageView!
    @IBOutlet weak var imageBG: UIImageView!
    @IBOutlet weak var backBtn: UIButton!
    @IBOutlet weak var addNoteBtn: UIButton!
    @IBOutlet weak var addTextView: UITextView!
    @IBOutlet weak var titleLib: UILabel!
    var noteData = String()
    let placeholderText = "Add something about this location..."
    var userIsEditing = true
    var titleName = String()
    
    let appDelegate = UIApplication.shared.delegate as! AppDelegate
    var context:NSManagedObjectContext!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUIView()
        self.titleLib.text = titleName
        addTextView.delegate = self
        if userIsEditing == true {
            addTextView.text =  noteData
        }else {
            addTextView.text =  placeholderText
        }
        addTextView.textColor = UIColor.lightGray
    }
    
   
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        if textView.text == placeholderText {
            textView.text = ""
        }
        return true
    }

    func textViewDidEndEditing(_ textView: UITextView) {
        if textView.text.isEmpty {
            textView.text = placeholderText
        }
    }
    @IBAction func backBtnAction(_ sender: UIButton) {
        self.reloadAction?()
        dismiss(animated: true)
       
    }
    
    @IBAction func addNoteAction(_ sender: Any) {
        
        let nameExists = isNameExisting(name: self.titleLib.text ?? "")
        if nameExists {
            saveOrUpdateData(name: self.titleLib.text ?? "", addNotes: addTextView.text)
        } else {
            print("The name does not exist in Core Data.")
        }
    }
    
    
    func isNameExisting(name: String) -> Bool {
        context = appDelegate.persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Locations")
        fetchRequest.predicate = NSPredicate(format: "name == %@", name)
        
        do {
            let count = try context.count(for: fetchRequest)
            return count > 0 // If count is greater than 0, the name exists
        } catch {
            print("Error checking if name exists: \(error)")
            return false
        }
    }
    
    
    func saveOrUpdateData(name: String, addNotes: String) {
        context = appDelegate.persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Locations")
        fetchRequest.predicate = NSPredicate(format: "name == %@", name)
        do {
            let existingObjects = try context.fetch(fetchRequest) as? [NSManagedObject] ?? []
            if let existingObject = existingObjects.first {
                existingObject.setValue(addNotes, forKey: "notes")
                try context.save()
                self.reloadAction?()
                dismiss(animated: true, completion: nil)
            } else {
                if let entity = NSEntityDescription.entity(forEntityName: "Locations", in: context) {
                    let managedObject = NSManagedObject(entity: entity, insertInto: context)
                    managedObject.setValue(name, forKey: "name")
                    managedObject.setValue(addNotes, forKey: "notes")
                    self.reloadAction?()
                    try context.save()
                }
            }
        } catch {
            print("Error saving or updating data: \(error)")
        }
    }

    func openDatabse()
        {
            context = appDelegate.persistentContainer.viewContext
            let entity = NSEntityDescription.entity(forEntityName: "Locations", in: context)
            let newUser = NSManagedObject(entity: entity!, insertInto: context)
            saveData(UserDBObj:newUser)
        }

        func saveData(UserDBObj:NSManagedObject)
        {
            UserDBObj.setValue(addTextView.text, forKey: "notes")
            print("Storing Data..")
            do {
                try context.save()
            } catch {
                print("Storing data Failed")
            }

           
        }
    func setupUIView(){
        
        addTextView.layer.applyCornerRadiusShadow(color: .black,alpha: 0.38, x: 0, y: 3,blur: 10,spread: 0,cornerRadiusValue: 8)
        addTextView.layer.masksToBounds = true
        
        backBtn.layer.applyCornerRadiusShadow(color: .black,alpha: 0.38, x: 0, y: 3,blur: 10,spread: 0,cornerRadiusValue: 8)
        backBtn.layer.masksToBounds = true
        
        addNoteBtn.layer.applyCornerRadiusShadow(color: .black,alpha: 0.38, x: 0, y: 3,blur: 10,spread: 0,cornerRadiusValue: 8)
        addNoteBtn.layer.masksToBounds = true
        
        haertBtn.layer.applyCornerRadiusShadow(color: .black,alpha: 0.38, x: 0, y: 3,blur: 10,spread: 0,cornerRadiusValue: 8)
        haertBtn.layer.masksToBounds = true
    }
        
       
}
