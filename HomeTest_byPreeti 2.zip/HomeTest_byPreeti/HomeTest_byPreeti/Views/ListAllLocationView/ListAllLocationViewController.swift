//
//  ListAllLocationViewController.swift
//  HomeTest_byPreeti
//
//  Created by Preeti Dhankar on 28/01/24.
//

import UIKit
import CoreData

class ListAllLocationViewController: UIViewController {

    let appDelegate = UIApplication.shared.delegate as! AppDelegate
    var context:NSManagedObjectContext!
    @IBOutlet weak var tableView: UITableView!
    var listData: NSArray = [] {
        didSet {
            self.tableView.reloadData()
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tableView.register(UINib(nibName: "ListLocationTableViewCell", bundle: nil), forCellReuseIdentifier: "ListAllLocationCell")
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.fetchData()
    }
    
    
    
}

extension ListAllLocationViewController:UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return listData.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ListAllLocationCell") as! ListLocationTableViewCell
        let Item = self.listData[indexPath.row]
        
        let referencelatitude = (Item as AnyObject).latitude
        let referencelongitude = (Item as AnyObject).longitude
//        let sortedLocations = locations.sorted { $0.distance(to: referenceLocation) < $1.distance(to: referenceLocation) }
        
        cell.locationNameLib?.text = (Item as AnyObject).name
        cell.locationDesLib?.text = (Item as AnyObject).notes
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let Item = self.listData[indexPath.row]
        let detailVC = self.storyboard?.instantiateViewController(withIdentifier: "DetailViewController") as! DetailViewController
        detailVC.reloadAction = {
            self.fetchData()
        }
        detailVC.titleName = (Item as AnyObject).name
        if (Item as AnyObject).notes != nil {
            detailVC.userIsEditing = true
            detailVC.noteData = (Item as AnyObject).notes ?? ""
        }else{
            detailVC.userIsEditing = false
        }
        self.present(detailVC, animated: true, completion: nil)
    }
    

//////////////Data Save And Fetching Data..////////////
    
    func fetchData()
    {
       
        context = appDelegate.persistentContainer.viewContext
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Locations")
        request.returnsObjectsAsFaults = false
        do {
            let result = try context.fetch(request)
            let uniqueObjects = removeDuplicates(from: result as! [NSManagedObject])
            self.listData = uniqueObjects as NSArray
            
        } catch {
            print("Fetching data Failed")
        }
    }

    func removeDuplicates(from objects: [NSManagedObject]) -> [NSManagedObject] {
        var uniqueObjects = [NSManagedObject]()
        var uniqueObjectIDs = Set<NSManagedObjectID>()
        for object in objects {
            if !uniqueObjectIDs.contains(object.objectID) {
                uniqueObjects.append(object)
                uniqueObjectIDs.insert(object.objectID)
            }
        }
        
        return uniqueObjects
    }
    
}
