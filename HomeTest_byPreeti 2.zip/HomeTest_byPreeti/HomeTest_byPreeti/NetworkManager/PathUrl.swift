//
//  PathUrl.swift
//  HomeTest_byPreeti
//
//  Created by Preeti Dhankar on 28/01/24.
//

import Foundation

enum PathUrl {
    case locationsList
    case errorLocationsList
    
    func getString() -> String {
        switch self {
        case .locationsList:
            return "fkAyNYGF"
        case .errorLocationsList:
            return "fkAyNYGF123"
        }
    }
}
