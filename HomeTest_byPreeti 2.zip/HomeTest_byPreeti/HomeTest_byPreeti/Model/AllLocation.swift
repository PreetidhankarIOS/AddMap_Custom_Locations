//
//  AllLocation.swift
//  HomeTest_byPreeti
//
//  Created by Preeti Dhankar on 28/01/24.
//

import Foundation
import Combine


struct LocationData: Decodable {
    var locations: [locations]
}

struct locations: Decodable {
    var name: String
    var lat: Double
    var lng: Double
}

