//
//  NetworkResponseProtocol.swift
//  HomeTest_byPreeti
//
//  Created by Preeti Dhankar on 28/01/24.
//

import Foundation

protocol NetworkResponseProtocol {
    func didReceiveError(error: Error)
    func didReceivedDataFromAPI<T: Decodable>(data: T)
}
