//
//  ListLocationTableViewCell.swift
//  HomeTest_byPreeti
//
//  Created by Preeti Dhankar on 28/01/24.
//

import UIKit

class ListLocationTableViewCell: UITableViewCell {

    @IBOutlet weak var locationDesLib: UILabel!
    @IBOutlet weak var locationNameLib: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        locationDesLib.layer.applyCornerRadiusShadow(color: .black,
                                    alpha: 0.38,
                                    x: 0, y: 3,
                                    blur: 10,
                                    spread: 0,
                                    cornerRadiusValue: 8)
        locationDesLib.layer.masksToBounds = true
        locationNameLib.layer.applyCornerRadiusShadow(color: .black,
                                    alpha: 0.38,
                                    x: 0, y: 3,
                                    blur: 10,
                                    spread: 0,
                                    cornerRadiusValue: 8)
        locationNameLib.layer.masksToBounds = true
     
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

       
    }
    
}
