//
//  ApiManager.swift
//  HomeTest_byPreeti
//
//  Created by Preeti Dhankar on 28/01/24.
//

import Foundation

struct ApiManager {
    private static let baseUrl = "https://pastebin.com/"
    private static let api = "raw/"
    static func api(_ pathString: PathUrl? = nil) -> String {
        guard let newPath = pathString else {
            return baseUrl + api
        }

        let path = baseUrl + api + newPath.getString()
        return path
    }

}

