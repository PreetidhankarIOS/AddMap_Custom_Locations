//
//  ViewController.swift
//  HomeTest_byPreeti
//  Created by Preeti Dhankar on 27/01/24.
//

import UIKit
import MapKit
import CoreLocation
import CoreData


class ViewController: UIViewController, CLLocationManagerDelegate, MKMapViewDelegate {
    
    let locationManager = CLLocationManager()
    @IBOutlet weak var mapViewe: MKMapView!
    var placeNameText: String = ""
    var locationsData: [locations] = [locations]()
    var fetchListData: NSArray = []
    
    let appDelegate = UIApplication.shared.delegate as! AppDelegate
    var context:NSManagedObjectContext!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleTap(_:)))
        mapViewe.addGestureRecognizer(tapGesture)
        self.locationManager.requestWhenInUseAuthorization()
        DispatchQueue.global().async {
            if CLLocationManager.locationServicesEnabled() {
                self.locationManager.delegate = self
                self.locationManager.desiredAccuracy = kCLLocationAccuracyBest
                self.locationManager.startUpdatingLocation()
            }
        }
        mapViewe.delegate = self
        mapViewe.mapType = .standard
        mapViewe.isZoomEnabled = true
        mapViewe.isScrollEnabled = true
        
        if let coor = mapViewe.userLocation.location?.coordinate{
            mapViewe.setCenter(coor, animated: true)
            
        }

        LocationListModel(networkManager: NetworkManager()).fetchLocations(completion: {
            data in
            self.locationsData = data

            self.annotationsOnMap()
        })

    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        
    }
    
    @objc func handleTap(_ gestureRecognizer: UITapGestureRecognizer) {
        // Get the location of the tap gesture
        let geocoder = CLGeocoder()
        let location = gestureRecognizer.location(in: mapViewe)
        let coordinate = mapViewe.convert(location, toCoordinateFrom: mapViewe)
        let annotation = MKPointAnnotation()
        annotation.coordinate = coordinate
        
        geocoder.reverseGeocodeLocation(CLLocation(latitude: coordinate.latitude, longitude: coordinate.longitude)) { (placemarks, error) in
            if let error = error {
                print("Reverse geocoding error: \(error.localizedDescription)")
                return
            }
            
            if let placemark = placemarks?.first {
                // Get the name or address from the placemark
                if let name = placemark.name {
                    print("Name: \(name)")
                    annotation.title = name
                    self.mapViewe.addAnnotation(annotation)
                    
                    let locationModel = LocationDataModel(name: annotation.title ?? "", lat: coordinate.latitude, long: coordinate.longitude)
                    self.saveDataToCoreData(array: [locationModel])
                    
                } else {
                    print("No name found")
                }
                
            }
        }
        
        mapViewe.setCenter(coordinate, animated: true)
        
        
        
    }
    
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let locValue:CLLocationCoordinate2D = manager.location!.coordinate
        mapViewe.mapType = MKMapType.standard
        let span = MKCoordinateSpan()
        let region = MKCoordinateRegion(center: locValue, span: span)
        mapViewe.setRegion(region, animated: true)
        
    }
    
    func annotationsOnMap() {
   
        var dataModel = [LocationDataModel]()
        
        for location in locationsData {
            dataModel.append(LocationDataModel(name: location.name, lat: location.lat, long: location.lng))
        }
        saveDataToCoreData(array: dataModel)
    }
    
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        let identifier = "Capital"
        
        var annotationView = mapView.dequeueReusableAnnotationView(withIdentifier: identifier)
        
        if annotationView == nil {
            annotationView = MKMarkerAnnotationView(annotation: annotation, reuseIdentifier: identifier)
            annotationView!.isEnabled = true
            annotationView!.canShowCallout = true
        } else {
            annotationView!.annotation = annotation
        }
        
        let btn = UIButton(type: .detailDisclosure)
        btn.addTarget(self, action: #selector(annotationClicked), for: .touchUpInside)
        annotationView!.rightCalloutAccessoryView = btn
        return annotationView
        
    }
    
    func mapView(_ mapView: MKMapView, didSelect view: MKAnnotationView) {
        placeNameText = (view.annotation?.title ?? "") ?? ""
    }
    
    @objc func annotationClicked() {
        let detailVC = self.storyboard?.instantiateViewController(withIdentifier: "DetailViewController") as! DetailViewController
        detailVC.titleName = placeNameText
        self.present(detailVC, animated: true, completion: nil)
    }
    
    @IBAction func AllLocationBtnAction(_ sender: UIBarButtonItem) {
        
        let listVC = self.storyboard?.instantiateViewController(withIdentifier: "ListAllLocationViewController") as! ListAllLocationViewController
        self.navigationController?.pushViewController(listVC, animated: true)
        
    }
    
    func saveDataToCoreData(array: [LocationDataModel]) {
        context = appDelegate.persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Locations")
        for item in array {
            
            fetchRequest.predicate = NSPredicate(format: "name == %@", item.name)
            do {
                let existingObjects = try context.fetch(fetchRequest) as? [NSManagedObject] ?? []
                if let existingObject = existingObjects.first {
                    existingObject.setValue(item.name, forKey: "name")
                    existingObject.setValue(item.lat, forKey: "latitude")
                    existingObject.setValue(item.long, forKey: "longitude")
                } else {
                    if let entity = NSEntityDescription.entity(forEntityName: "Locations", in: context) {
                        let managedObject = NSManagedObject(entity: entity, insertInto: context)
                        managedObject.setValue(item.name, forKey: "name")
                        managedObject.setValue(item.lat, forKey: "latitude")
                        managedObject.setValue(item.long, forKey: "longitude")
                    }
                }
                do {
                    try context.save()
                    self.fetchData()
                } catch {
                    print("Failed to save data: \(error)")
                }
            } catch {
                print("Error saving or updating data: \(error)")
            }
        }
    }
    
    //////////////Data Save And Fetching Data..////////////
        
    func fetchData()
        {
           
            context = appDelegate.persistentContainer.viewContext
            let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Locations")
            request.returnsObjectsAsFaults = false
            do {
                let result = try context.fetch(request)
                let uniqueObjects = removeDuplicates(from: result as! [NSManagedObject])
                self.fetchListData = uniqueObjects as NSArray
                
                for location in fetchListData {
                    let annotations = MKPointAnnotation()
                    annotations.title = (location as AnyObject).name
                    annotations.coordinate = CLLocationCoordinate2D(latitude: (location as AnyObject).latitude, longitude: (location as AnyObject).longitude)
                    mapViewe.addAnnotation(annotations)
                    let locationCoordinate2d = annotations.coordinate
                    let span = MKCoordinateSpan(latitudeDelta: 0.220, longitudeDelta: 0.220)
                    let region = MKCoordinateRegion(center: locationCoordinate2d, span: span)
                    self.mapViewe.setRegion(region, animated: true)
                }
                
            } catch {
                print("Fetching data Failed")
            }
        }

        func removeDuplicates(from objects: [NSManagedObject]) -> [NSManagedObject] {
            var uniqueObjects = [NSManagedObject]()
            var uniqueObjectIDs = Set<NSManagedObjectID>()
            for object in objects {
                if !uniqueObjectIDs.contains(object.objectID) {
                    uniqueObjects.append(object)
                    uniqueObjectIDs.insert(object.objectID)
                }
            }
            
            return uniqueObjects
        }
    
    
}

