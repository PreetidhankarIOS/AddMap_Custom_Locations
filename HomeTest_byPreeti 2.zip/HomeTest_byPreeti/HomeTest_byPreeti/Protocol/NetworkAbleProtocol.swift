//
//  NetworkAbleProtocol.swift
//  HomeTest_byPreeti
//
//  Created by Preeti Dhankar on 28/01/24.
//

import Foundation
import Combine

protocol NetworkAbleProtocol {
    
    func getDataFromApi<T:Decodable>(urlRequest: URLRequest, type: T.Type) -> AnyPublisher<T,Error> where T : Decodable

}
