//
//  LocationDataModel.swift
//  HomeTest_byPreeti
//
//  Created by Preeti Dhankar on 28/01/24.
//

import Foundation

struct LocationDataModel {
    let name: String
    let lat: Double
    let long: Double
}
